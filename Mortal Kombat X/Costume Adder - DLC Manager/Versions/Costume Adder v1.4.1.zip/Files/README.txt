Place in this folder:
Coalesced.Eng
Coalesced.ini
X64TOC.txt

Place in "Content":
CHAR_name_costume.xxx
CHAR_name_costume_SCRIPTASSETS.xxx
DISM_name_costume.xxx
DISM_name_costume_DLC.xxx (IF FOUND)
CHAR_name_costume.mko